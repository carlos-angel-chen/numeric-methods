from math import log2,copysign,floor,isnan

BIAS = 2**(5-1)-1

BINARY16_BITS_NAN = [True]*16
BINARY16_BITS_INF = [False]+[True]*5+[False]*10
BINARY16_BITS_MINF= [True]*6+[False]*10 

def float_to_list(float_num: float):
    if isnan(float_num):#float_num is float('nan'):
        return BINARY16_BITS_NAN
    elif float_num == float('inf'):
        return BINARY16_BITS_INF
    elif float_num == float('-inf'):
        return BINARY16_BITS_MINF

    sign = copysign(1,float_num) # Empleado en vez de un ">0" debido a que funciona con -0.0 también
    if float_num == 0:
        if sign == 1:
            return [False]*16
        else:
            return [True] + [False]*15

    exp = int(floor(log2(abs(float_num))))

    if exp > 2**5-1 - BIAS:
        if sign == 1:
            return BINARY16_BITS_INF
        else:
             return BINARY16_BITS_MINF
    man = []
    float_num = abs(float_num)
    if exp < 1 - BIAS:
        #sub normal
        float_num /= 2**(1 - BIAS)
        exp = 0
    #    for pos in range(10):
    #        float_num*=2
    #        if float_num >= 1:
    #            float_num-=1
    #            man += [True]
    #        else:
    #            man += [False]

    else:
        float_num /= 2**exp
        float_num -= 1
        exp += BIAS
    #    for pos in range(10):
    #        float_num*=2
    #        if float_num >= 1:
    #            float_num-=1
    #            man += [True]
    #        else:
    #            man += [False]

    for pos in range(10):
        float_num*=2
        if float_num >= 1:
            float_num-=1
            man += [True]
        else:
            man += [False]

    exp_list = []
    for pos in range(5):
        if exp >= 2**(4-pos):
            exp-= 2**(4-pos)
            exp_list+=[True]
        else:
            exp_list+=[False]


    list = [sign == -1] + exp_list + man

    print(sign)
    print(exp_list)
    print(man)

    return list

def list_to_float(list_num):
    if list_num == BINARY16_BITS_INF:
        print("INF")
        return float('inf')
    elif list_num == BINARY16_BITS_MINF:
        print("-INF")
        return float('-inf')

    sign = list_num[0]
    exp_list = list_num[1:6]
    man_list = list_num[6:16]

    if exp_list == [True]*5 and man_list != [False]*10:
        print("NAN")
        return float('nan')

    man = 0
    for position in range(10):
        man += (2**position)*man_list[-(1+position)]
    man /= 2**(10)

    if exp_list == [False]*5:
        exp = 1
    else:
        man += 1
        exp = 0
        for position in range(5):
            exp += (2**position)*exp_list[-(1+position)]
    exp -= BIAS

    f = ((-1)**sign * man * 2**exp)

    print(sign)
    print(BIAS)
    print(exp)
    print(man)
    print(f)

    return f

    

class binary16:
    def __init__(self,float_num: float):
        if type(float_num) is not float:
            float_num = float(float_num)
        self.float_num = float_num
        self.bits = []
        self.d = 0.0

    def __add__(self, other):
        return binary16(self.float_num + other.float_num)
    
    def print(self):
        print(self.float_num)

    def __mul__(self,other):
        print("mul")
        return self

    def __truediv__(self,other):
        print("div")
        return self

    def __eq__(self,other):
        print("eq")
        return "eq"

    def __ne__(self,other):
        print("ne")
        return "ne"


